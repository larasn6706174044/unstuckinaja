<?php
/*

# workflow reload history
- select semua stuck yang memiliki nim bersangkutan
- tampilkan ke history

 */

require_once '../auth.php';
require_once '../model/model.php';

$nim = $_SESSION['user_login'];

$sql = "SELECT * FROM stuck WHERE nim=:nim ORDER BY editDate DESC";
$params = [':nim' => $nim];

$result = selectAll($sql, $params);
