<?php 

// include kan model nya
require_once '../../model/model.php';

require_once '../../auth.php';

// ambil data nim dari session
$nim = $_SESSION['login'];

if (isset($_POST['update-profile'])) {
  /* Algoritma
  1. Check apakah file gambar atau tidak
  2. Batasin ukuran gambar
  3. Check apakah file gambar atau fake
  4. Ubah nama file
  5. Simpan
   */

  // filter data
  $nama = filter_input(INPUT_POST, 'nama', FILTER_SANITIZE_STRING);
  $motto = filter_input(INPUT_POST, 'motto', FILTER_SANITIZE_STRING);
  $bio = filter_input(INPUT_POST, 'bio', FILTER_SANITIZE_STRING);
  $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
  $twitter = filter_input(INPUT_POST, 'twitter', FILTER_SANITIZE_STRING);
  $github = filter_input(INPUT_POST, 'github', FILTER_SANITIZE_STRING);
  $siteUrl = filter_input(INPUT_POST, 'siteUrl', FILTER_SANITIZE_URL);

  // simpan default name dari photo
  $imageName = $_SESSION['userArr']['photo'];

  if (($_FILES['photo']['name'] != "")) {
    $uploadOk = 1;
    $targetDir = '../../assets/img/';
    echo $imageFileType = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
    echo $targetFile = $targetDir . $nim . '.' . $imageFileType;

    // variable ini kan jadi nama gambar di database
    echo $imageName = $nim . '.' . $imageFileType;

    echo $imageSize = $_FILES['photo']['size'];

    // check file gambar
    if ($imageFileType != 'png' && $imageFileType != 'jpg' && $imageFileType != 'jpeg' && $imageFileType != 'svg' && $imageFileType != 'gif') {
      $uploadOk = 0;
      echo 'bukan gambar';
    }

    // check ukuran
    if ($imageSize > 1000000) {
      $uploadOk = 0;
      echo 'kebesaran';
    }

    // check apakah gambar nya fake atau tidak
    $check = getimagesize($_FILES['photo']['tmp_name']);

    if (!$check) {
      $uploadOk = 0;
      echo 'bukan gambar';
    }

    if ($uploadOk == 0) {
      //  jika upload gagal
      echo 'gagal';
      header('location: ../edit-profile.php?error=image_failed');
      return;
    }

    // jika semua oke, copy gambar
    // hapus file sebelumnya
    if (file_exists($targetDir . $_SESSION['userArr']['photo'])) {
      if ($_SESSION['userArr']['photo'] != 'default.svg') {
        // hapus
        unlink($targetDir . $_SESSION['userArr']['photo']);
      }
    }
    
    // upload file
    if (!move_uploaded_file($_FILES['photo']['tmp_name'], $targetFile)) {
      header('location: ../edit-profile.php?error=upload_failed');
      return;
    }
    
    
  }

  
    // update ke database
    
    // validasikan url
    if (!filter_var($siteUrl, FILTER_VALIDATE_URL) && $siteUrl != '') {
        header('location: ../edit-profile.php?error=invalid_url');
        return;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) && $email != '') {
      header('location: ../edit-profile.php?error=invalid_email');
      return;
    }

    // siapkan sql, bind parameter
    $sql = "UPDATE member SET nama=:nama, motto=:motto, bio=:bio, email=:email, twitter=:twitter, github=:github, siteUrl=:siteUrl, photo=:photo WHERE nim=:nim";

    $params = [
      ':nama' => $nama,
      ':motto' => $motto,
      ':bio' => $bio,
      ':email' => $email,
      ':twitter' => $twitter,
      ':github' => $github,
      ':siteUrl' => $siteUrl,
      ':photo' => $imageName,
      ':nim' => $nim,
    ];

    // jika semua ok, simpan
    $status = crud($sql, $params);
    if ($status == true) {
      header('location: ../index.php');
    } else {
      header('location: ../index.php?error');
    }

} else {
  header('location: ../edit-profile.php');
}
