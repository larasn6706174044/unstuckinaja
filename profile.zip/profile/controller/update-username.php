<?php 

// include kan model nya
require_once '../../model/model.php';

require_once '../../auth.php';

// ambil data nim dari session
$nim = $_SESSION['login'];

if (isset($_POST['change-username'])) {

  // ambil input
  // filter input
  // check apakah password sesuai dengan database
  // check ketersediaan username
  // simpan
  // redirect ke profile
  
  $nim = $_SESSION['login'];

  $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
  $password = $_POST['password'];

  // jika password tidak match, maka error
  $sql = "SELECT password FROM member WHERE nim=:nim";
  $params = [
    ':nim' => $nim
  ];
  
  $result = select($sql, $params);

  // cocokkan password
  if (!password_verify($password, $result['password'])) {
    header('location: ../edit-profile.php?error=pwd_failed');
    return;
  }

  // jika username sama dengan sebelumnya, maka redirect langsung ke profile
  if ($username == $_SESSION['userArr']['username']) {
    header('location: ../');
    return;
  }
  
  $sql = "SELECT * FROM member WHERE username=:username AND username != :currentUsername";
  $params = [ 
    ':username' => $username,
    ':currentUsername' => $_SESSION['userArr']['username']
  ];

  // jika username telah dipakai, error
  $result = select($sql, $params);
  if ($result) {
    header('location: ../edit-profile.php?error=registered_member');
    return;
  }

  // jika semua ok, simpan kemudian redirect
  $sql = "UPDATE member SET username=:username WHERE nim=:nim";
  $params = [
    ':username' => $username, 
    ':nim' => $nim
  ];

  $status = crud($sql, $params);
  if ($status) {
    header('location: ../');
    return;
  } else {
    header('location: ../edit-profile.php?error=update_failed');
    return;
  }

}