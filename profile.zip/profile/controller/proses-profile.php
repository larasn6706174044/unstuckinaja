<?php 

// include kan kode model
require_once('../model/model.php');

$nim = $_SESSION['user_login'];

// bind params
$params = [
  ':nim' => $nim,
];

function get_data_profile() {
  
  global $nim, $params;
  
  // ambil data user dari database
  $sql = "SELECT * FROM member WHERE nim=:nim";

  // eksekusi query
  return $result_set_user = select($sql, $params);

}

function get_last_emblem() {
  
  global $nim, $params;

  // ambil emblem terakhir dari user
  $sql = "
    SELECT ue.emblemId, e.namaEmblem, m.nim
    FROM useremblem ue
    INNER JOIN emblem e
    ON ue.emblemId = e.emblemId
    INNER JOIN member m
    ON ue.nim = m.nim
    WHERE m.nim=:nim ORDER BY e.emblemId DESC ";
  
  return $result_set_last_emblem = select($sql, $params);
  
}

?>