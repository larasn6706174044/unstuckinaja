<?php 

// include kan model nya
require_once '../../model/model.php';

require_once '../../auth.php';

// ambil data nim dari session
$nim = $_SESSION['login'];

if (isset($_POST['update-password'])) {

  // ambil input
  // filter input
  // cocokkan password
  // check password apakah sama dengan konfirmasi password
  // check apakah username telah dipakai atau tidak
  // check password apakah samadengan database
  // simpan ke database
  // redirect ke profile

  // filter input
  $oldPwd = $_POST['oldPwd'];
  $newPwd = $_POST['newPwd'];
  $confirmPwd = $_POST['confirmPwd'];

  // cocokkan password
  if ($newPwd !== $confirmPwd) {
    echo 'tidak sama';
    header('location: ../edit-profile.php?error=pwd_mismatch');
    return;
  }

  // check old password to database
  $sql = "SELECT * FROM member WHERE nim=:nim";
  $params = [':nim' => $nim];
  $user = select($sql, $params);

  if (!$user) {
    header('location: ../../daftar/index.php?error=nim_not_found');
    return;
  }
  
  // jika tidak sama redirect
  if (!password_verify($oldPwd, $user['password'])) {
    header('location: ../edit-profile.php?error=pwd_failed');
    return;
  }

  print_r($newPwd);
  
  // jika semua ok, update
  $sql = "UPDATE member SET password=:password WHERE nim=:nim";
  $params = [
    ':password' => password_hash($newPwd, PASSWORD_DEFAULT),
    ':nim' => $nim,
  ];

  if (crud($sql, $params)) {
    header('location: ../index.php');
    return;
  } else {
    header('location: ../edit-profile.php?error=update_failed');
    return;
  }

} else {
  header('location: ../edit-profile.php');
}
