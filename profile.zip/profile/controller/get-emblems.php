<?php 

function get_emblems() {
  global $points;
  global $nim;
  /*
  # workflow load emblem
  - check apakah user pernah mendapatkan emblem pertama
  - check poin user == 100
  - jika >= 100
  - berikan emblem
  - jika sudah pernah mendapatkan emblem dengan id tersebut
  - lakukan lagi untuk emblem kedua, ketiga, dan seterusnya
  */

  $sql_check_user_emblem = "SELECT * FROM useremblem WHERE emblemId=:emblemId AND nim=:nim";

  $sql_insert = "INSERT INTO useremblem (emblemId, nim) VALUES (:emblemId, :nim)";

  $sql_get_emblem = "SELECT * FROM emblem";
  $result_set_emblem = selectAll($sql_get_emblem, []);

  // check emblem pertama
  $params = [
    ':nim' => $nim,
    ':emblemId' => $result_set_emblem[0]['emblemId'],
  ];

  // variable ini digunakan untuk menampilkan emblem terakhir dari user
  $namaEmblem = $result_set_last_emblem['namaEmblem'];

  if (!select($sql_check_user_emblem, $params) && ($points >= 100 && $points < 200)) {

  // ganti nama emblem
    $namaEmblem = $result_set_emblem[0]['namaEmblem'];

    crud($sql_insert, $params);

    ?>

  <script>
    $( document ).ready(function() {
      // Handler for .ready() called.
      $.alert({
          title: "<?php echo $namaEmblem ?>",
          content: 'Wow! Selamat, kamu berhasil mendapatkan emblem baru "Zero"',
          theme: 'modern',
          icon: 'fa fa-code',
          animation: 'scale',
          type: 'dark'
      });
    });
  </script>

  <?php
  }

  // check emblem kedua
  $params = [
    ':nim' => $nim,
    ':emblemId' => $result_set_emblem[1]['emblemId'],
  ];

  if (!select($sql_check_user_emblem, $params) && ($points >= 200 && $points < 350)) {

  // ganti nama emblem
    $namaEmblem = $result_set_emblem[1]['namaEmblem'];

    crud($sql_insert, $params);

    ?>
  <script>
    $( document ).ready(function() {
      // Handler for .ready() called.
      $.alert({
          title: 'Ninja',
          content: 'Yosh! Selamat, kamu udah mendapatkan jurus baru, "Ninja"',
          theme: 'modern',
          icon: 'fa fa-code',
          animation: 'scale',
          type: 'dark'
      });
    });
  </script>

  <?php
  }

  // check emblem ketiga
  $params = [
    ':nim' => $nim,
    ':emblemId' => $result_set_emblem[2]['emblemId'],
  ];

  if (!select($sql_check_user_emblem, $params) && ($points >= 350 && $points < 500)) {

  // ganti nama emblem
    $namaEmblem = $result_set_emblem[2]['namaEmblem'];

    crud($sql_insert, $params);

    ?>
    <script>
    $( document ).ready(function() {
      // Handler for .ready() called.
      $.alert({
          title: 'Pro',
          content: 'Zuperr! Sekarang kamu udah mendapatkan emblem "Pro"',
          theme: 'modern',
          icon: 'fa fa-code',
          animation: 'scale',
          type: 'dark'
      });
    });
  </script>
  <?php
  }

  // check emblem keempat
  $params = [
    ':nim' => $nim,
    ':emblemId' => $result_set_emblem[3]['emblemId'],
  ];

  if (!select($sql_check_user_emblem, $params) && ($points >= 500)) {

  // ganti nama emblem
    $namaEmblem = $result_set_emblem[3]['namaEmblem'];

    crud($sql_insert, $params);

    ?>
    <script>
    $( document ).ready(function() {
      // Handler for .ready() called.
      $.alert({
          title: 'Hero',
          content: 'Yoshaaa! Sekarang kamu sudah jadi "Hero" !!!',
          theme: 'modern',
          icon: 'fa fa-code',
          animation: 'scale',
          type: 'dark'
      });
    });
  </script>
  <?php
  }

  // setelah insert emblem
  // load semua emblem
  $sql_display_emblems = "
  SELECT e.emblemId, e.namaEmblem, e.icon
  FROM useremblem ue
  INNER JOIN emblem e
  ON e.emblemId = ue.emblemId
  INNER JOIN member m
  ON m.nim = ue.nim
  WHERE ue.nim = :nim	";

  $params = [
    ':nim' => $nim,
  ];

  $emblem_list = selectAll($sql_display_emblems, $params);


}


?>